/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 heart heart.png 
 * Time-stamp: Saturday 04/02/2022, 00:46:38
 * 
 * Image Information
 * -----------------
 * heart.png 9@9
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEART_H
#define HEART_H

extern const unsigned short heart[81];
#define HEART_SIZE 162
#define HEART_LENGTH 81
#define HEART_WIDTH 9
#define HEART_HEIGHT 9

#endif

