/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 enemy2 enemy2.png 
 * Time-stamp: Saturday 04/02/2022, 19:45:18
 * 
 * Image Information
 * -----------------
 * enemy2.png 19@19
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY2_H
#define ENEMY2_H

extern const unsigned short enemy2[361];
#define ENEMY2_SIZE 722
#define ENEMY2_LENGTH 361
#define ENEMY2_WIDTH 19
#define ENEMY2_HEIGHT 19

#endif

