/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 enemy3 enemy3.png 
 * Time-stamp: Saturday 04/02/2022, 19:59:35
 * 
 * Image Information
 * -----------------
 * enemy3.png 11@11
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY3_H
#define ENEMY3_H

extern const unsigned short enemy3[121];
#define ENEMY3_SIZE 242
#define ENEMY3_LENGTH 121
#define ENEMY3_WIDTH 11
#define ENEMY3_HEIGHT 11

#endif

