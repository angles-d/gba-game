/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 enemy1 enemy1.png 
 * Time-stamp: Saturday 04/02/2022, 19:45:11
 * 
 * Image Information
 * -----------------
 * enemy1.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY1_H
#define ENEMY1_H

extern const unsigned short enemy1[625];
#define ENEMY1_SIZE 1250
#define ENEMY1_LENGTH 625
#define ENEMY1_WIDTH 25
#define ENEMY1_HEIGHT 25

#endif

