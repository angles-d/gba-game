This is a simple shooter game.
Use the arrow keys to move the green player block around.
Use the R button to shoot (A on the keyboard). You can only have 3 shots on screen at a time.
If Bob hits you, you will lose a life.
Hit Bob 3 times with a projectile to win the game.
Good luck!
