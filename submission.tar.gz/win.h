/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 win win.png 
 * Time-stamp: Saturday 04/02/2022, 19:45:34
 * 
 * Image Information
 * -----------------
 * win.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_H
#define WIN_H

extern const unsigned short win[38400];
#define WIN_SIZE 76800
#define WIN_LENGTH 38400
#define WIN_WIDTH 240
#define WIN_HEIGHT 160

#endif

